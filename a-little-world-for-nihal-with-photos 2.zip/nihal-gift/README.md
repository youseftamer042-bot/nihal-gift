# A Little World for Nihal

A small, responsive, interactive romantic gift website built with Next.js.

## Run locally

1. Install Node.js (LTS).
2. In this folder, run `npm install`.
3. Run `npm run dev`.
4. Open the local address shown in your terminal.

## Deploy to Vercel

1. Create a new GitHub repository and upload the contents of this folder.
2. In Vercel, choose **Add New → Project** and import that repository.
3. Vercel detects Next.js automatically. Click **Deploy**.
4. Share the resulting URL with Nihal.

The project uses static export (`output: "export"`), so it can also be hosted on any static hosting provider.

## Personalize the message

Open `app/page.tsx` and edit:
- The `reasons` array to add your own specific memories and reasons.
- The letter text inside the first content card.
- The final surprise message.

Tip: Add a real photo of you two in a later version for an even more personal ending.